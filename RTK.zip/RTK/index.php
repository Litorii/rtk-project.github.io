<?php
include 'assets/components/header.php'; 

?>

<!-- Шапка -->
<div class="header">
    <div class="logo">
    <a href="/index.php"><img src="/assets/img/logo.svg" alt="logo"></a>
    </div>

    <nav class="nav_menu">
        <li class="nav_bar">            
            <ul><a href="#services">Услуги</a></ul>
            <ul><a href="#auto-park">Автопарк</a></ul>
            <ul><a href="#map">Контакты</a></ul>
        </li>       
        <li class="nav_bar"> 
        <?php if (!isset($_SESSION['admin']) && !isset($_SESSION['user'])) { ?>
            <form action="assets/components/log.php">
            <button class="link2">Авторизация</button>
            </form>
            <form action="assets/components/reg.php">
            <button class="link">Регистрация</button> 
            </form>           
                <?php } elseif (isset($_SESSION['admin'])) { ?>
            <form action="assets/components/admin-panel.php">
            <button class="link2">Админ панель</button>
            </form>
            <form action="assets/components/logout.php">
            <button class="link">Выход</button> 
            </form>  
                   
                <?php } elseif (isset($_SESSION['user'])) { ?>
            <form action="assets/components/user-panel.php">
            <button class="link2">Личный кабинет</button>
            </form>
            <form action="assets/components/logout.php">
            <button class="link">Выход</button> 
            </form>         
                    
                <?php } ?>
        </li>
    </nav>
</div>

<video class="video" src="/assets/img/body.mp4" autoplay muted loop></video>
<div class="main-cont">
    <div class="line"></div>
    <p class="transport-title1">Транспорт и логистика</p>
    <div class="line"></div>
    <p class="transport-title2">Автомобильная перевозка и экспедирование грузов по всей территории РФ и странам СНГ</p>
    <div class="button-main-cont">
    <a href="#anchor"><button class="left-button">Доставка</button></a> 
    <a href="#map"><button class="right-button">Наш адрес</button></a>
    </div>
</div>
</div>

<?php if (!isset($_SESSION['admin']) && !isset($_SESSION['user'])) { ?>
    <div class="container" id="anchor">   
    <div class="delivery">
        <div class="form">
        <form action="assets/components/state.php" class="form" method="post">
            <h2 class="animation a1">Рассчитать доставку</h2>
            <p class="animation a7">*Чтобы рассчитать доставку, Вам нужно зарегистрироваться</p>           

            <button type="submit" class="animation a6"><a class="button-a6" href="assets/components/reg.php">Зарегистрироваться</a></button>
            </form>
        </div>
        
    </div>
</div>
    
    <?php } elseif (isset($_SESSION['admin'])) { ?>
        <div class="container" id="anchor">
    <img src="/assets/img/1.png" class="cars" alt="1">
    <div class="delivery">
        <div class="form">
        <form action="assets/components/state.php" class="form" method="post">
            <h2 class="animation a1">Рассчитать доставку</h2>
            <input type="text" class="form-field animation a3" name="wher-from" required placeholder="Откуда">
            <input type="text" class="form-field animation a4" name="wher" required placeholder="Куда">
            <input type="text" class="form-field animation a4" name="weight-volume" required placeholder="Вес/Объем">
            <input type="text" class="form-field animation a4" name="full-name" required placeholder="ФИО">
            <input type="text" class="form-field animation a4" name="phone" required placeholder="Телефон">
            <input type="text" class="form-field animation a4" name="email" required placeholder="Email">

            <button type="submit" class="animation a6">Отправить</button>
            </form>
        </div>
        
    </div>
</div>
        <?php } elseif (isset($_SESSION['user'])) { ?>
<div class="container" id="anchor">
    <img src="/assets/img/1.png" class="cars" alt="1">
    <div class="delivery">
        <div class="form">
        <form action="assets/components/state.php" class="form" method="post">
            <h2 class="animation a1">Рассчитать доставку</h2>
            <input type="text" class="form-field animation a3" name="wher-from" required placeholder="Откуда">
            <input type="text" class="form-field animation a4" name="wher" required placeholder="Куда">
            <input type="text" class="form-field animation a4" name="weight-volume" required placeholder="Вес/Объем">
            <input type="text" class="form-field animation a4" name="full-name" required placeholder="ФИО">
            <input type="text" class="form-field animation a4" name="phone" required placeholder="Телефон">
            <input type="text" class="form-field animation a4" name="email" required placeholder="Email">

            <button type="submit" class="animation a6">Отправить</button>
            </form>
        </div>
        
    </div>
</div>
<?php } ?>

<div class="services" id="services">
    <div class="services-info">
        <div class="services-title">
            <h1>Наши услуги</h1>
            <p>Транспортная компания грузоперевозок ООО “РТК” предоставляет услуги по перевозке грузов автомобильным транспортом, международным грузоперевозкам,
                консолидации грузов, перевозке опасных и негабаритных грузов, услугам по хранению и складированию, страхованию груза и отслеживанию его перемещения.</p>
        </div>
    </div>
</div>

<div class="services-cards">
    <div class="list">
        <div class="ser-card">
            <h1 class="card__title">Перевозке грузов автомобильным транспортом</h1>
            <div class="img-card">
                <img src="/assets/img/card1.svg" class="ser__img" />
            </div>
        </div>
        <div class="ser-card">
            <h1 class="card__title">Консолидации грузов</h1>
            <div class="img-card">
                <img src="/assets/img/card2.svg" class="ser__img" />
            </div>
        </div>
        <div class="ser-card">
            <h1 class="card__title">Перевозка опасных грузов</h1>
            <div class="img-card">
                <img src="/assets/img/card3.svg" class="ser__img" />
            </div>
        </div>
        <div class="ser-card">
            <h1 class="card__title">Перевозка негабаритных грузов</h1>
            <div class="img-card">
                <img src="/assets/img/card4.svg" class="ser__img" />
            </div>
        </div>
        <div class="ser-card">
            <h1 class="card__title">Страхование груза и отслеживание</h1>
            <div class="img-card">
                <img src="/assets/img/card5.svg" class="ser__img" />
            </div>
        </div>
        <div class="ser-card">
            <h1 class="card__title">Международные грузоперевозки</h1>
            <div class="img-card">
                <img src="/assets/img/card6.svg" class="ser__img" />
            </div>
        </div>
    </div>
</div>

<div class="services" id="auto-park">
    <div class="services-info">
        <div class="services-title">
            <h1>Автопарк</h1>
            <p>Компания имеет обширный автопарк включающий грузовые автомобили различных моделей.
                Грузовые автомобили включают в себя различные типы прицепов и полуприцепов для перевозки различных видов грузов.
                Все транспортные средства регулярно проходят техническое обслуживание и находятся в хорошем состоянии.
            </p>
        </div>
    </div>
</div>

<div class="auto-park">
    <div class="car1">
        <div class="img-car">
            <img src="/assets/img/car1-auto-park.svg" class="car__img" />
        </div>
        <h1 class="car__title">Рефрижераторная фура</h1>
        <p class="car__title2">Изотермический фургон рефрижератора оборудован мотором для контроля температурного режима внутри кузова.</p>
        <div class="car-info">
            <img src="/assets/img/car-info.svg" class="car-auto-park__img" />
        </div>
    </div>
    <div class="car2">
        <div class="img-car">
            <img src="/assets/img/car2-auto-park.svg" class="car__img" />
        </div>
        <h1 class="car__title">Низкорамный трал</h1>
        <p class="car__title2">Низкорамные тралы (платформы) — специализированные транспортные средства для перевозки негабаритных грузов.</p>
        <div class="car-info">
            <img src="/assets/img/car-info.svg" class="car-auto-park__img" />
        </div>
    </div>
    <div class="car3">
        <div class="img-car">
            <img src="/assets/img/car3-auto-park.svg" class="car__img" />
        </div>
        <h1 class="car__title">Тентованная фура (Еврофура)</h1>
        <p class="car__title2">Основное преимущество еврофуры: защитный тент, под которым грузу не угрожают воздействия окружающей среды.</p>
        <div class="car-info">
            <img src="/assets/img/car-info.svg" class="car-auto-park__img" />
        </div>
    </div>
</div>


<?php
include 'assets/components/footer.php';
?>