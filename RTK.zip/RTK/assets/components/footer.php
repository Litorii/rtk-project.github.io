<div style="position:relative;overflow:hidden;" id="map"><a href="https://yandex.ru/maps/66/omsk/?utm_medium=mapframe&utm_source=maps" style="color:#eee;font-size:12px;position:absolute;top:0px;">Омск</a><a href="https://yandex.ru/maps/66/omsk/house/kombinatskaya_ulitsa_16/Y0oYdA5oTUUDQFtvfXx3cXpmZg==/?ll=73.298404%2C55.060653&utm_medium=mapframe&utm_source=maps&z=17" style="color:#eee;font-size:12px;position:absolute;top:14px;">Комбинатская улица, 16 на карте Омска — Яндекс Карты</a><iframe src="https://yandex.ru/map-widget/v1/?ll=73.298404%2C55.060653&mode=whatshere&whatshere%5Bpoint%5D=73.298404%2C55.060652&whatshere%5Bzoom%5D=17&z=17" width="100%" height="410" frameborder="" allowfullscreen="true" style="position:relative;"></iframe></div>
     
    <div class="footer">
        <div class="footer-cont">
        <div class="left-info-footer">
            <img src="/assets/img/logo-footer.svg" alt="logo">
            <p><b>Тел:</b> 8-800-301-09-35</p>
            <p><b>E-mail:</b> rtk@mail.ru</p>
            <p><b>Юридический адрес:</b> 644035, Омская область, г Омск, Комбинатская ул, д. 16, офис 1</p>
        </div>
        <div class="right-info-footer">
            <p><b>ОГРН:</b> 1215500025839</p>
            <p><b>ИНН:</b> 5501275051</p>
            <p><b>КПП:</b> 550101001</p>
            <p><b>ОКПО </b> 57824363</p>
        </div>

        <div class="copyrate">Все права защищены 2021-2024 ©RTK</div>
        
        </div>
    </footer>
</body>
</html>