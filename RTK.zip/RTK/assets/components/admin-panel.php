<?php
include 'core.php';
isAdmin();
$chupa = isset($_SESSION['admin']['id']) ? $_SESSION['admin']['id'] : null;
$user = $mysqli->query("SELECT login FROM users WHERE id = $chupa");
$application = $mysqli->query("SELECT `wher-from`, `wher`, `weight-volume`, `full-name`, `phone`, `email` FROM `Application`");
?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/assets/css/main.css">
    <link rel="stylesheet" href="/assets/css/footer.css">
    <link rel="stylesheet" href="/assets/css/admin-panel.css">
    <link rel="shortcut icon" href="/assets/img/icon.svg" />
    <title>Панель администратора</title>
</head>

<body>


    <div class="header">
        <div class="logo">
            <a href="/index.php"><img src="/assets/img/logo.svg" alt="logo"></a>
        </div>

        <nav class="nav_menu">
        <li class="nav_bar"> 
        <?php if (!isset($_SESSION['admin']) && !isset($_SESSION['user'])) { ?>
            <form action="log.php">
            <button class="link2">Авторизация</button>
            </form>
            <form action="reg.php">
            <button class="link">Регистрация</button> 
            </form>           
                <?php } elseif (isset($_SESSION['admin'])) { ?>
            <form action="admin-panel.php">
            <button class="link2">Админ панель</button>
            </form>
            <form action="logout.php">
            <button class="link">Выход</button> 
            </form>  
                   
                <?php } elseif (isset($_SESSION['user'])) { ?>
            <form action="user-panel.php">
            <button class="link2">Личный кабинет</button>
            </form>
            <form action="logout.php">
            <button class="link">Выход</button> 
            </form>         
                    
                <?php } ?>
        </li>
    </nav>
</div>

    <video class="video" src="/assets/img/body.mp4" autoplay muted loop></video>
    <div class="user-panel">
        <div class="welcome-admin">
            <h1>Панель администратора</h1>
            <p>Здравствуйте,
                <?php if ($user->num_rows > 0) {
                    while ($row = $user->fetch_assoc()) {
                        echo $row['login'];
                    }
                } ?> !</p>
        </div>
    </div>
    <div class="button-main-cont">
    <a href="#application"><button class="left-button">Заявления</button></a>
    </div>

    <div class="application-title" id="application">
        <p>Заявления на рассчет доставки</p>
    </div>

    <div class="application">
        <?php foreach ($application as $item) { ?>
            <div class="app-block">
                <div class="left-info">
                    <p><b>Откуда:</b> <?= $item['wher-from'] ?></p>
                    <p><b>Куда:</b> <?= $item['wher'] ?></p>
                    <p><b>Вес/Объем:</b> <?= $item['weight-volume'] ?></p>
                </div>
                <div class="right-info">
                    <p><b>ФИО:</b> <?= $item['full-name'] ?></p>
                    <p><b>Телефон:</b> <?= $item['phone'] ?></p>
                    <p><b>Email:</b> <?= $item['email'] ?></p>
                </div>

            </div>

        <?php } ?>
    </div>