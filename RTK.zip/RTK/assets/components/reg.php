<?php
 include "core.php";

 
if ($_POST) {
    $password = md5($_POST['password']);
    $result = $mysqli->query("INSERT INTO `users`(`login`, `tel`, `email`, `password`) 
    VALUES (
        '{$_POST['login']}',
        '{$_POST['tel']}',
        '{$_POST['email']}',
        '$password'
        )");
        redirect('../../index.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/reg.css">
    <title>Регистрация</title>
</head>
<body>



<div class="container">
  <div class="left">
    <div class="header">   
      <h2 class="animation a1">Регистрация</h2>
      <h4 class="animation a2">Зарегистрируйте свою учетную запись, используя адрес электронной почты, логин, пароль и телефон</h4>
    </div>
    <div class="form">
    <form action="" class="form" method="post">
      <input type="email" class="form-field animation a3" name="email" required placeholder="Email">
      <input type="text" class="form-field animation a3" name="login" required placeholder="Логин">
      <input type="password" class="form-field animation a4" name="password" required  placeholder="Пароль">
      <input type="tel" class="form-field animation a4" name="tel" required placeholder="Телефон">

      <div class="title-reg">
      <div class="left-title">
      <p class="animation a5"><a href="/index.php">Главная</a></p>
      </div>
      <div class="right-title">
      <p class="animation a5"><a href="log.php">Авторизация</a></p>
      </div>
      </div>      
      
      <button type="submit" class="animation a6">Зарегистрироваться</button>
</form>
    </div>
  </div>
  <div class="right"></div>
</div>

</body>
</html>