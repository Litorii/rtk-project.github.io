<?php
include 'core.php';
$user_id = isset($_SESSION['user']['id']) ? $_SESSION['user']['id'] : null;
if ($_POST) {
    $application = $mysqli->query("INSERT INTO `Application`(`id`, `user_id`, `wher-from`, `wher`, `weight-volume`, `full-name`, `phone`, `email`) 
    VALUES (
        NULL,
        $user_id,
        '{$_POST['wher-from']}',
        '{$_POST['wher']}',
        '{$_POST['weight-volume']}',
        '{$_POST['full-name']}',
        '{$_POST['phone']}',
        '{$_POST['email']}'
        )");
        redirect('../../index.php');
}


?>