<?php
include 'core.php';

if (isset($_POST['log'])) {
    $login = $_POST['login'];
    $password = md5($_POST['password']);
    $users = $mysqli->query("SELECT id, isAdmin FROM users WHERE login = '$login' AND password = '$password'");
    
    if ($users->num_rows == 0) {
        $_SESSION['errors']['login'];
        redirect('../../index.php');
        exit();
    }
    
    $user = $users->fetch_assoc();
    
    if ($user['isAdmin'] == '1') {
        $_SESSION['admin']['id'] = $user['id']; // Устанавливаем сессию для админа
    } elseif ($user['isAdmin'] == '0') {
        $_SESSION['user']['id'] = $user['id']; // Устанавливаем сессию для обычного пользователя
    }
    redirect('../../index.php');
}
exit();
?>