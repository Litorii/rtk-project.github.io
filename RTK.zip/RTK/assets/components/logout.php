<?php
include 'core.php';
session_start();
session_unset();
redirect('../../index.php');
?>