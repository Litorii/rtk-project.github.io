<?php
session_start();
$mysqli = new mysqli('localhost', 'root', '', 'rtk');


$mysqli->set_charset('utf8mb4');

function redirect($url = false)
{
    if ($url) {
        header("Location: " . $url);
    } else {
        header("Location: {$_SERVER['HTTP_REFERER']}");
    }
}

function isAdmin($bool = false)
{
    if ($bool) {
        return isset($_SESSION['admin']);
    } else {
        if (!isset($_SESSION['admin'])) {
            redirect('/');
        }
    }
}