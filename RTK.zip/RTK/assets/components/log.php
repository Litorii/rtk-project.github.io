<?php
include 'core.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../css/log.css">
  <title>Авторизация</title>
</head>

<body>



  <div class="container">
    <div class="left">
      <div class="header">

        <h2 class="animation a1">Авторизация</h2>
        <h4 class="animation a2">Войдите в свою учетную запись, используя логин и пароль</h4>
      </div>
      <div class="form">
        <form action="logh.php" class="form" method="post">
          <input type="text" class="form-field animation a3" name="login" required placeholder="Логин">
          <input type="password" class="form-field animation a4" name="password" required placeholder="Пароль">

          <div class="title-reg">
            <div class="left-title">
              <p class="animation a5"><a href="/index.php">Главная</a></p>
            </div>
            <div class="right-title">
              <p class="animation a5"><a href="reg.php">Регистрация</a></p>
            </div>
          </div>

          <button class="animation a6" name="log">Войти</button>
        </form>
      </div>
    </div>
    <div class="right"></div>
  </div>

</body>

</html>